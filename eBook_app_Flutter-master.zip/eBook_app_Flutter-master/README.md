# eBook App - Flutter UI

## [Watch it on YouTube](https://youtu.be/ACdraZRANaU)

<!-- **Packages we are using:**

- flutter_svg: [link](https://pub.dev/packages/flutter_svg) -->

<!-- **Fonts**

- Poppins [link](https://fonts.google.com/specimen/Poppins) -->

**UI Credit**

- Design by: Peeely [link](https://www.uplabs.com/posts/free-book-reading-app)

Flamingo is an eBook (reading book) app design by flutter, at home page it shows you some recommended books, also the book of the day. At the bottom you gonna find your most recent book that you read. On details page book info with it's chapters. note that this is UI only.

### eBook App Final UI

![App UI](/attachment.png)
